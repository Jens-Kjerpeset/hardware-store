'use client';
import { useEffect, useRef, useState } from 'react';

export default function HardwareStoreGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const skipRef = useRef<(() => void) | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [gameId, setGameId] = useState(0);
  const isPausedRef = useRef(false);

  const togglePause = () => {
    isPausedRef.current = !isPausedRef.current;
    setIsPaused(isPausedRef.current);
  };

  const restartGame = () => {
    setIsPaused(false);
    isPausedRef.current = false;
    setIsGameOver(false);
    setGameId(prev => prev + 1);
    setIsPlaying(true);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const collisionCanvas = document.createElement('canvas');
    const offCtx = collisionCanvas.getContext('2d', { willReadFrequently: true });

    const handleResize = () => {
      // Sync internal resolution with display size
      canvas.width = canvas.parentElement?.clientWidth || 800;
      canvas.height = canvas.parentElement?.clientHeight || 400;
      ctx.imageSmoothingEnabled = false;
    };
    
    // Initial size mapping and resize listener
    handleResize();
    window.addEventListener('resize', handleResize);

    // Load Sprites
    const idleImg = new Image();
    idleImg.src = '/sprites/Reapz-idle.png';
    const runImg = new Image();
    runImg.src = '/sprites/Reapz-run.png';
    const jumpImg = new Image();
    jumpImg.src = '/sprites/Reapz-jump.png';
    const sitImg = new Image();
    sitImg.src = '/sprites/Reapz-sit.png';
    const rideImg = new Image();
    rideImg.src = '/sprites/Reapz-ride.png';
    const floorImg = new Image();
    floorImg.src = '/sprites/desert_floor.jpeg';
    const hutImg = new Image();
    hutImg.src = '/sprites/Troll Hut.png';

    // NPC Definitions Map
    const loadImg = (src: string) => { const img = new Image(); img.src = src; return img; };
    type NPCType = { id: string, walk?: HTMLImageElement, idle?: HTMLImageElement, scaleModifier?: number, fpsModifier?: number, flipDefault?: boolean };
    const npcTypes: NPCType[] = [
      { id: 'Bog Lord', idle: loadImg('/sprites/Bog Lord-idle.png'), scaleModifier: 1.5 },
      { id: 'Assassin', walk: loadImg('/sprites/Assassin-walk.png') },
      { id: 'Roc', walk: loadImg('/sprites/Roc-walk.png') },
      { id: 'Stinger', walk: loadImg('/sprites/Stinger-walk.png'), flipDefault: true, scaleModifier: 1.5 },
      // Basilisk inherently walks backwards so we flip it by default and scale it 2x
      { id: 'Basilisk', walk: loadImg('/sprites/Basilisk-walk.png'), idle: loadImg('/sprites/Basilisk-idle.png'), scaleModifier: 2, flipDefault: true },
      { id: 'Hyena', walk: loadImg('/sprites/Hyena-walk.png'), idle: loadImg('/sprites/Hyena-idle.png') },
      // Sea Giant is towering (4x) and moves slowly (half fps)
      { id: 'Sea giant', walk: loadImg('/sprites/Sea giant-walk.png'), idle: loadImg('/sprites/Sea giant-idle.png'), scaleModifier: 4, fpsModifier: 0.5 },
      { id: 'Silithid', walk: loadImg('/sprites/Silithid-walk.png'), idle: loadImg('/sprites/Silithid-idle.png'), scaleModifier: 1.5, fpsModifier: 4.0 },
      { id: 'Wringing Thorns', idle: loadImg('/sprites/Wringing Thorns-spritesheet.png'), scaleModifier: 1.0 },
      { id: 'Strider', walk: loadImg('/sprites/Strider-run.png'), idle: loadImg('/sprites/Strider-idle.png'), scaleModifier: 1.5 },
      { id: 'Pirate', idle: loadImg('/sprites/Pirate-fire_blunderbuss.png'), scaleModifier: 1.5, fpsModifier: 0.4 },
      { id: 'Dragon', walk: loadImg('/sprites/Dragon-flying_forward,_flapping_its_wings.png'), scaleModifier: 10.0 }
    ];

    // Game state
    let animationFrameId: number;
    let lastTime = performance.now();
    
    const player = {
      x: 250,
      y: canvas.height / 2 - 12,
      z: 0,
      vz: 0,
      isJumping: false,
      slowTimer: 0,
      fastTimer: 0,
      sitTimer: 0,
      width: 24,
      height: 24,
      speed: 300, // pixels per second vertically
      frameTimer: 0,
      currentFrame: 0,
      facingLeft: false,
      isFrozen: false,
      frozenSpriteId: '',
      frozenFrame: 0,
      knockbackTimer: 0,
      isTrappedTimer: 0,
      trappedEntityId: -1,
      isMounted: false,
    };

    const keys = {
      ArrowUp: false,
      ArrowDown: false,
      ArrowLeft: false,
      ArrowRight: false,
      w: false,
      s: false,
      a: false,
      d: false,
    };

    let backgroundOffset = 0;
    const baseRunSpeed = 200; // pixels per second background scroll
    let distanceTraveled = 0;
    let timeRemaining = 223.0; // 3 minutes 43 seconds
    let hasSpawnedDragon = false;
    
    let hazardsHit = 0;
    let boostsCollected = 0;

    if (isPlaying) {
      // Map the debug skip function to the ref
      skipRef.current = () => {
        timeRemaining = Math.max(0.5, timeRemaining - 210.0);
      };
    }

    let globalIdCounter = 0;
    type Entity = { 
        id: number,
        parentId?: number,
        isBaby?: boolean,
        hasPlayedStealthSound?: boolean,
        hasPlayedAggroSound?: boolean,
        enragedTimer: number,
        childSpawnTimer: number,
        x: number, y: number, width: number, height: number, 
        hit: boolean, type: 'sit_hazard',
        npcType: NPCType, state: 'walk' | 'idle', stateTimer: number, localSpeedX: number, localSpeedY: number, facingLeft: boolean,
        sprite: HTMLImageElement, currentFrame: number, frameTimer: number 
    };
    let entities: Entity[] = [];
    let spawnTimer = 1.0; // First obstacle in 1 second

    // Input listening
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
         if (!player.isJumping && player.sitTimer <= 0) {
            player.vz = 400; // Jump power
            player.isJumping = true;
         }
         e.preventDefault();
         return;
      }
      if (keys.hasOwnProperty(e.key)) {
        keys[e.key as keyof typeof keys] = true;
        // Prevent default scrolling for arrow keys while focused on the game
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
          e.preventDefault();
        }
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (keys.hasOwnProperty(e.key)) {
        keys[e.key as keyof typeof keys] = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Main loop
    const render = (time: number) => {
      const deltaTime = (time - lastTime) / 1000;
      lastTime = time;

      if (isPausedRef.current) {
         animationFrameId = requestAnimationFrame(render);
         return;
      }

      // Animate Sprite Frame based on state constraints
      if (!player.isFrozen) {
          player.frameTimer += deltaTime;
      }

      // Unified animation speed
      let fpsThreshold = 1 / 24; // Default 24 FPS

      if (player.frameTimer >= fpsThreshold && !player.isFrozen) {
         let minFrame = 0;
         let maxFrame = 24; // 25 frames total
         
         // User requested Jump animation to snap to specific indices
         if (player.sitTimer > 0 && !player.isFrozen) {
            // Sit uses a custom mapped time sequence, so let currentFrame count up infinitely
            minFrame = 0;
            maxFrame = 999999;
         } else if (player.isJumping) {
            minFrame = 2; // Frame 3 (0-indexed)
            maxFrame = 14; // Frame 15 (0-indexed)
         } else {
            // Default running animation constraints
            minFrame = 0; // Frame 1 (0-indexed)
            maxFrame = 22; // Frame 23 (0-indexed)
         }

         player.currentFrame++;
         if (player.currentFrame < minFrame || player.currentFrame > maxFrame) {
             player.currentFrame = minFrame;
         }

         player.frameTimer -= fpsThreshold;
      }

      // Handle active tracking debuffs and buffs
      if (player.knockbackTimer > 0) {
          player.knockbackTimer -= deltaTime;
          player.x -= 400 * deltaTime; // physically shove player backward
          if (player.knockbackTimer < 0) player.knockbackTimer = 0;
      }
      if (player.isTrappedTimer > 0) {
          player.isTrappedTimer -= deltaTime;
          if (player.isTrappedTimer < 0) player.isTrappedTimer = 0;
      }
      if (player.sitTimer > 0) {
        player.sitTimer -= deltaTime;
        if (player.sitTimer <= 0) {
           player.sitTimer = 0;
           player.isFrozen = false;
        }
      }
      if (player.slowTimer > 0) {
        player.slowTimer -= deltaTime;
        if (player.slowTimer < 0) player.slowTimer = 0;
      }
      if (player.fastTimer > 0) {
        player.fastTimer -= deltaTime;
        if (player.fastTimer < 0) player.fastTimer = 0;
      }

      let activePlayerSpeed = player.speed;
      let activeRunSpeed = isPlaying ? baseRunSpeed : 0;

      if (player.sitTimer > 0 || player.isTrappedTimer > 0) {
        activePlayerSpeed = 0;
        activeRunSpeed = 0;
      } else if (player.slowTimer > 0) {
        activePlayerSpeed *= 0.5;
        activeRunSpeed *= 0.5;
      } else if (player.fastTimer > 0) {
        activePlayerSpeed *= 1.6;
        activeRunSpeed *= 1.6;
      }

      // Update Player Y
      if (player.knockbackTimer <= 0) {
          if (keys.ArrowUp || keys.w) {
            player.y -= activePlayerSpeed * deltaTime;
          }
          if (keys.ArrowDown || keys.s) {
            player.y += activePlayerSpeed * deltaTime;
          }
          
          // Update Player X (auto-runner defaults to facing right unless actively running left)
          player.facingLeft = (keys.ArrowLeft || keys.a) && !(keys.ArrowRight || keys.d);

          if (keys.ArrowLeft || keys.a) {
            player.x -= activePlayerSpeed * deltaTime;
          }
          if (keys.ArrowRight || keys.d) {
            player.x += activePlayerSpeed * deltaTime;
          }
      } else {
          // Force backflip pose while soaring backward
          player.facingLeft = false;
      }
      
      // Update Player Z (Jumping)
      if (player.isJumping) {
        player.z += player.vz * deltaTime;
        player.vz -= 1400 * deltaTime; // Gravity
        if (player.z <= 0) {
           player.z = 0;
           player.vz = 0;
           player.isJumping = false;
        }
      }

      // Clamp player bounds tightly to canvas
      const skyHeight = 5 * 32; // 160 pixels (top 5 squares)
      // Visual padding to prevent floating in the sky zone
      const playerMinY = skyHeight + (96 * 0.35); 
      if (player.y < playerMinY) player.y = playerMinY;
      if (player.y + player.height > canvas.height) {
        player.y = canvas.height - player.height;
      }
      
      if (player.x < 0) player.x = 0;
      if (player.x + player.width > canvas.width) {
        player.x = canvas.width - player.width;
      }

      // Update background moving left (simulating player running right)
      backgroundOffset -= activeRunSpeed * deltaTime;

      // 1. Procedural Parallax Oasis Horizon
      
      // Sky Gradient (Dithered pixel-art bands for organic transition)
      const skyColors = [
         '#1e1b4b', '#2e186a', '#3f1680', '#4c1d95', '#5f1885', '#701a75', 
         '#98196b', '#be185d', '#d01b52', '#e11d48', '#ed5e29', '#f59e0b', 
         '#f9bf28', '#fde047'
      ];
      const bandHeight = Math.ceil(120 / skyColors.length);
      for (let i = 0; i < skyColors.length; i++) {
          ctx.fillStyle = skyColors[i];
          ctx.fillRect(0, i * bandHeight, canvas.width, bandHeight + 1);
          
          // Organic dithering (checkerboard fade into the upper band)
          if (i > 0) {
              ctx.fillStyle = skyColors[i - 1];
              for (let dx = 0; dx < canvas.width; dx += 4) {
                 ctx.fillRect(dx, i * bandHeight, 2, 2);
                 ctx.fillRect(dx + 2, i * bandHeight + 2, 2, 2);
              }
          }
      }

      // Distant Mountains (0.05x Parallax - Organic Sine Waves, true 2x2 density)
      const mtOffset = (backgroundOffset * 0.05) % 1000;
      const lmtOffset = mtOffset > 0 ? mtOffset - 1000 : mtOffset;
      const mSize = 2; // Strict 2x2 density mapped to the foreground art
      const f = (Math.PI * 2) / 1000; // Continuous looping frequency spanning 1000px bounds
      
      // Layer 1: Background Mountains (Lighter)
      ctx.fillStyle = '#5b21b6'; 
      for (let loop = 0; loop < Math.ceil(canvas.width / 1000) + 1; loop++) {
          let loopX = Math.floor(lmtOffset + loop * 1000);
          for (let x = 0; x < 1000; x += mSize) {
              let h = Math.sin(x * f) * 15 + Math.sin(x * f * 2.3) * 10 + Math.sin(x * f * 4.1) * 8 + 35;
              h = Math.floor(h / mSize) * mSize; 
              if (h > 0) ctx.fillRect(loopX + x, 120 - h, mSize + 1, h + 1); 
          }
      }

      // Layer 2: Foreground Mountains (Darker, overlapping)
      ctx.fillStyle = '#312e81'; 
      const mtOffsetFront = (backgroundOffset * 0.07) % 1000;
      const lmtOffsetFront = mtOffsetFront > 0 ? mtOffsetFront - 1000 : mtOffsetFront;
      
      for (let loop = 0; loop < Math.ceil(canvas.width / 1000) + 1; loop++) {
          let loopX = Math.floor(lmtOffsetFront + loop * 1000);
          for (let x = 0; x < 1000; x += mSize) {
              let h = Math.sin((x * f) + 2) * 22 + Math.sin((x * f * 3.7) + 1) * 12 + Math.sin((x * f * 6) + 3) * 5 + 25;
              h = Math.floor(h / mSize) * mSize; 
              
              if (h > 0) {
                  ctx.fillRect(loopX + x, 120 - h, mSize + 1, h + 1);
                  // Highlight Rim Texture
                  if (Math.floor(x / mSize) % 2 === 0) {
                      ctx.fillStyle = '#3f3c9e';
                      ctx.fillRect(loopX + x, 120 - h, mSize, mSize);
                      ctx.fillStyle = '#312e81'; 
                  }
              }
          }
      }

      // Ocean Water (Dithered gradient + noise)
      const waterY = 120;
      const waterHeight = skyHeight - waterY;
      const waterColors = ['#0ea5e9', '#0284c7', '#0369a1'];
      const wBand = Math.ceil(waterHeight / waterColors.length);
      
      for (let i = 0; i < waterColors.length; i++) {
          ctx.fillStyle = waterColors[i];
          ctx.fillRect(0, waterY + (i * wBand), canvas.width, wBand + 1);
          
          if (i > 0) {
              ctx.fillStyle = waterColors[i - 1];
              for (let dx = 0; dx < canvas.width; dx += 4) {
                 ctx.fillRect(dx, waterY + (i * wBand), 2, 2);
                 ctx.fillRect(dx + 2, waterY + (i * wBand) + 2, 2, 2);
              }
          }
      }
      
      // Wave hints
      ctx.fillStyle = '#7dd3fc';
      const waveOffset = (backgroundOffset * 0.1) % 120;
      const lwaveOffset = waveOffset > 0 ? waveOffset - 120 : waveOffset;
      for (let w = lwaveOffset; w < canvas.width; w += 120) {
          let flooredW = Math.floor(w);
          ctx.fillRect(flooredW, waterY + 6, 8, 2);
          ctx.fillRect(flooredW + 40, waterY + 18, 6, 2);
          ctx.fillRect(flooredW + 80, waterY + 28, 12, 2);
      }

      // Distant Sand Islands (0.15x Parallax - Organic Sine Formations)
      const islandOffset = (backgroundOffset * 0.15) % 1000;
      const lislandOffset = islandOffset > 0 ? islandOffset - 1000 : islandOffset;
      const iSize = 2; // Island structural density
      
      // Hardcoded explicit pixel-art Palm Tree mapping string for raw accuracy (2x2px)
      const palmSprite = [
        "  GGGG    ",
        " GGGGGG   ",
        "GG GG GG  ",
        "G      G  ",
        "   TT     ",
        "   TT     ",
        "   TT     "
      ];

      const drawPalm = (ox: number, oy: number) => {
          for (let row = 0; row < palmSprite.length; row++) {
              for (let col = 0; col < palmSprite[row].length; col++) {
                  const char = palmSprite[row][col];
                  if (char === 'G') ctx.fillStyle = '#15803d'; // Green
                  else if (char === 'T') ctx.fillStyle = '#78350f'; // Trunk
                  else continue;
                  ctx.fillRect(ox + (col * 2), oy + (row * 2), 2, 2);
              }
          }
      };
      
      for (let loop = 0; loop < Math.ceil(canvas.width / 1000) + 1; loop++) {
          let loopX = Math.floor(lislandOffset + loop * 1000);
          
          // Island 1 (x: 100 to 350)
          for (let x = 100; x < 350; x += iSize) {
              let nx = (x - 100) / 250; 
              let h = Math.sin(nx * Math.PI) * 12; 
              h += Math.sin(nx * Math.PI * 4) * 3; 
              h = Math.floor(h / iSize) * iSize;
              
              if (h > 0) {
                  ctx.fillStyle = '#fcd34d'; 
                  ctx.fillRect(loopX + x, 142 - h, iSize + 1, h + 1);
                  ctx.fillStyle = '#d97706'; 
                  ctx.fillRect(loopX + x, 142 - iSize, iSize + 1, iSize + 1);
              }
          }
          drawPalm(loopX + 180, 118);
          drawPalm(loopX + 240, 115);

          // Island 2 (x: 650 to 800)
          for (let x = 650; x < 800; x += iSize) {
              let nx = (x - 650) / 150; 
              let h = Math.sin(nx * Math.PI) * 8 + Math.sin(nx * Math.PI * 3) * 2; 
              h = Math.floor(h / iSize) * iSize;
              
              if (h > 0) {
                  ctx.fillStyle = '#fcd34d'; 
                  ctx.fillRect(loopX + x, 142 - h, iSize + 1, h + 1);
                  ctx.fillStyle = '#d97706'; 
                  ctx.fillRect(loopX + x, 142 - iSize, iSize + 1, iSize + 1);
              }
          }
          drawPalm(loopX + 700, 126);
      }

      // 2. Draw Repeating Desert Floor
      const groundHeight = canvas.height - skyHeight;
      if (floorImg.complete && floorImg.naturalWidth > 0) {
          // Scale logic to preserve the visual texture while locking height
          const ratio = groundHeight / floorImg.naturalHeight;
          const renderWidth = Math.max(1024, floorImg.naturalWidth * Math.max(0.2, ratio)); 
          
          let localOffset = backgroundOffset % renderWidth;
          if (localOffset > 0) localOffset -= renderWidth; // guarantee negative shift
          
          try {
             // Draw enough tiles to safely cover dynamically resizing ultra-wide monitors
             ctx.drawImage(floorImg, 0, 0, floorImg.naturalWidth, floorImg.naturalHeight, localOffset, skyHeight, renderWidth, groundHeight);
             ctx.drawImage(floorImg, 0, 0, floorImg.naturalWidth, floorImg.naturalHeight, localOffset + renderWidth, skyHeight, renderWidth, groundHeight);
             ctx.drawImage(floorImg, 0, 0, floorImg.naturalWidth, floorImg.naturalHeight, localOffset + renderWidth * 2, skyHeight, renderWidth, groundHeight);
          } catch(e) {}
      } else {
          // Fallback if image not ready
          ctx.fillStyle = '#292524'; // Warm stone tint
          ctx.fillRect(0, skyHeight, canvas.width, groundHeight);
      }

      // Draw Troll Hut securely mapped to visual scrolling coordinates
      if (hutImg.complete && hutImg.naturalWidth > 0) {
          const targetHutHeight = Math.min(canvas.height * 0.45, hutImg.naturalHeight);
          const hutRatio = targetHutHeight / hutImg.naturalHeight;
          const hutWidth = hutImg.naturalWidth * hutRatio;
          
          // Mathematically slide it off mechanically against physical scroll data mapping the Center dynamically over Reapz!
          const scrollOffX = (player.x) - (hutWidth * 0.73) - distanceTraveled;
          if (scrollOffX + hutWidth > 0) {
              try {
                  const hutY = (canvas.height / 2) - targetHutHeight + 25;
                  ctx.drawImage(hutImg, 0, 0, hutImg.naturalWidth, hutImg.naturalHeight, scrollOffX, hutY, hutWidth, targetHutHeight);
              } catch(e) {}
          }
      }

      // Pre-compute Player drawing logic for pixel-perfect collision tests
      let pSpriteSheet = runImg;
      if (player.isFrozen) {
          if (player.frozenSpriteId === 'sit') pSpriteSheet = sitImg;
          else if (player.frozenSpriteId === 'jump') pSpriteSheet = jumpImg;
          else if (player.frozenSpriteId === 'idle') pSpriteSheet = idleImg;
          else pSpriteSheet = runImg;
      } else {
          if (player.isMounted) pSpriteSheet = rideImg;
          else if (player.isTrappedTimer > 0) pSpriteSheet = idleImg;
          else if (player.sitTimer > 0) pSpriteSheet = sitImg;
          else if (player.isJumping) pSpriteSheet = jumpImg;
          else if (activeRunSpeed === 0) pSpriteSheet = idleImg;
      }

      let pDrawnFrame = player.isFrozen ? player.frozenFrame : player.currentFrame;
      if (player.isMounted) {
          pDrawnFrame = 18;
      } else if (player.sitTimer > 0 && !player.isFrozen) {
          if (player.currentFrame === 0) pDrawnFrame = 0;
          else if (player.currentFrame === 1) pDrawnFrame = 9;
          else if (player.currentFrame === 2) pDrawnFrame = 18;
          else {
              const tick = Math.floor((player.currentFrame - 3) / 2);
              const pp = tick % 4;
              pDrawnFrame = pp <= 2 ? 22 + pp : 22 + (4 - pp);
          }
      }
      
      const pDrawW = 96;
      const pDrawH = 96;
      const pDrawX = player.x - (pDrawW / 2) + (player.width / 2);
      const pDrawY = player.y - player.z - pDrawH + player.height + 4;
      const pSourceX = (pDrawnFrame % 5) * (1280 / 5);
      const pSourceY = Math.floor(pDrawnFrame / 5) * (1280 / 5);

      // Master Spawn Controller
      if (isPlaying) {
          spawnTimer -= deltaTime;
      }
      if (spawnTimer <= 0 && isPlaying) {
        
        // Pick a random obstacle, rigidly blacklisting static environmental entities, generated objects, and solitary cinematic structures
        const allowedEnemies = npcTypes.filter(n => n.id !== 'Bullet' && n.id !== 'Wringing Thorns' && n.id !== 'Dragon');
        
        let width = 24;
        let height = 24;
        const npcType = allowedEnemies[Math.floor(Math.random() * allowedEnemies.length)];
        let startState: 'walk' | 'idle' = npcType.walk ? 'walk' : 'idle';
        if (npcType.walk && npcType.idle && Math.random() > 0.5) startState = 'idle';

        // Expanded Hitboxes based on NPC type
        if (npcType.id === 'Hyena') {
            width = 16; // Slightly reduced from 24
            height = 16;
        } else if (npcType.id === 'Bog Lord') {
            width = 48; // Increased from 24
            height = 48;
        } else if (npcType.id === 'Sea giant') {
            width = 80; // Greatly increased from 24
            height = 80;
        }

        // Calculate a safe minimum Y spawn so scaled sprites don't visually float in the sky 
        const scaleMod = npcType.scaleModifier || 1;
        const minSpawnY = skyHeight + ((96 * scaleMod) * 0.35); 

        // Local pacing speed (-X is walking left, +X is walking right). Scaled 2x.
        let localSpeedX = startState === 'walk' ? (Math.random() * 220 - 140) : 0;
        let localSpeedY = 0;
        if (startState === 'walk') {
            if (npcType.id === 'Roc') {
                localSpeedX = 0; // Rocs do not pace horizontally
                localSpeedY = Math.random() > 0.5 ? 90 : -90; // Start pacing Y
            } else if (npcType.id === 'Stinger') {
                localSpeedX = Math.random() * 160 - 100; // Normal wandering
                localSpeedY = Math.random() * 80 - 40;
            }
        }
        
        const newEntityY = minSpawnY + Math.random() * Math.max(0, canvas.height - minSpawnY - height);
        const spawnX = npcType.id === 'Bog Lord' ? canvas.width + 250 : canvas.width + 50;

        entities.push({
          id: globalIdCounter++,
          enragedTimer: 0,
          childSpawnTimer: npcType.id === 'Silithid' ? -1.0 : 0, 
          x: spawnX,
          y: newEntityY,
          width,
          height,
          hit: false,
          type: 'sit_hazard', // All NPCs force 2 second sit
          npcType,
          state: startState,
          stateTimer: 1.0 + Math.random() * 3.0,
          localSpeedX,
          localSpeedY,
          facingLeft: localSpeedX < 0 || localSpeedX === 0, // default facing left if standing still
          sprite: (startState === 'walk' ? npcType.walk : npcType.idle)!,
          currentFrame: Math.floor(Math.random() * 25),
          frameTimer: 0
        });

        // Bog Lord spawns 3 Wringing Thorns in the area around him automatically
        if (npcType.id === 'Bog Lord') {
            const thornType = npcTypes.find(n => n.id === 'Wringing Thorns');
            if (thornType) {
                for(let t=0; t<3; t++) {
                    const tY = minSpawnY + Math.random() * Math.max(0, canvas.height - minSpawnY - 40);
                    entities.push({
                        id: globalIdCounter++,
                        enragedTimer: 0,
                        childSpawnTimer: 0,
                        x: spawnX + (Math.random() * 300 - 150),
                        y: tY,
                        width: 40, // thorns have smaller functional hitbox logic
                        height: 40,
                        hit: false,
                        type: 'sit_hazard',
                        npcType: thornType,
                        state: 'idle',
                        stateTimer: 999, // stationary logic limits AI swapping
                        localSpeedX: 0,
                        localSpeedY: 0,
                        facingLeft: true,
                        sprite: thornType.idle!,
                        currentFrame: Math.floor(Math.random() * 25),
                        frameTimer: 0
                    });
                }
            }
        }
        
        // Slower spawn timer so the screen isn't entirely flooded with instant sits
        spawnTimer = 1.0 + Math.random() * 2.5; 
      }

      // Draw and Update Entities
      for (let i = entities.length - 1; i >= 0; i--) {
        const ent = entities[i];
        
        // Background flows left, local pacing speed adds to the vector
        ent.x -= (activeRunSpeed + -ent.localSpeedX) * deltaTime;
        ent.y += ent.localSpeedY * deltaTime;
        
        if (ent.localSpeedY !== 0) {
            const scaleMod = ent.npcType.scaleModifier || 1;
            const minSafeY = skyHeight + ((96 * scaleMod) * 0.35);
            if (ent.y < minSafeY) {
                ent.y = minSafeY;
                ent.localSpeedY *= -1; // Bounce off invisible sky limit
            }
            if (ent.y + ent.height > canvas.height) {
                ent.y = canvas.height - ent.height;
                ent.localSpeedY *= -1; // Bounce off bottom rim
            }
        }
        
        // Dynamically Spawn Baby Silithids!
        if (ent.npcType.id === 'Silithid' && !ent.isBaby && ent.childSpawnTimer !== 0) {
            if (ent.childSpawnTimer === -1.0) {
                // Wait until the mother is fully visible on screen before spawning the first baby
                if (ent.x + ent.width < canvas.width) {
                    ent.childSpawnTimer = 0.01; // Trigger instantly next tick
                }
            } else {
                ent.childSpawnTimer -= deltaTime;
                if (ent.childSpawnTimer <= 0) {
                    entities.push({
                      id: globalIdCounter++,
                      parentId: ent.id,
                      isBaby: true,
                      enragedTimer: 0,
                      childSpawnTimer: 0,
                      x: ent.x + ent.width / 2, // Spawn physically out of mother
                      y: ent.y + ent.height / 2,
                      width: 24, // Tighter hitbox
                      height: 24,
                      hit: false,
                      type: 'sit_hazard',
                      npcType: { ...ent.npcType, scaleModifier: 0.5 }, // Scaled down overlay 
                      state: 'walk',
                      stateTimer: 1.0 + Math.random() * 3.0,
                      localSpeedX: Math.random() * 220 - 140, // random local pacing
                      localSpeedY: Math.random() * 80 - 40,
                      facingLeft: true,
                      sprite: ent.npcType.walk || ent.sprite,
                      currentFrame: Math.floor(Math.random() * 25),
                      frameTimer: 0
                    });
                    
                    // Chance to spawn exactly one more baby later
                    if (Math.random() > 0.5) {
                        ent.childSpawnTimer = Math.random() * 3.0 + 2.0; 
                    } else {
                        ent.childSpawnTimer = 0; // Never spawn again
                    }
                }
            }
        }

        const scaleMod = ent.npcType.scaleModifier || 1;
        const drawWidth = 96 * scaleMod;
        const visualRightEdge = ent.x + (drawWidth / 2) + (ent.width / 2);
        
        if (visualRightEdge < 0) {
          entities.splice(i, 1);
          continue;
        }

        // Collision Check based on the drawn "pixels area" footprint
        if (!ent.hit) {
          // Establish entity drawn bounds
          const scaleMod = ent.npcType.scaleModifier || 1;
          let eDrawW = 96 * scaleMod; 
          let eDrawH = 96 * scaleMod;
          
          let eDrawX = ent.x - (eDrawW / 2) + (ent.width / 2);
          let eDrawY = ent.y - eDrawH + ent.height + 4; 

          // Procedural explicit boundaries (Bullet geometric parity)
          if (ent.npcType.id === 'Bullet') {
              eDrawW = ent.width;
              eDrawH = ent.height;
              eDrawX = ent.x;
              eDrawY = ent.y;
          }

          // Entity Head Bypass Offset (For towering giants)
          const enemyHeadMargin = ent.npcType.id === 'Sea giant' ? 100 : 0; // Giant's head is massive due to 4x scaling
          const hitEDrawY = eDrawY + enemyHeadMargin;
          const hitEDrawH = eDrawH - enemyHeadMargin;

          // Player Head Bypass Offset
          const headMargin = 30; // Shave 30 active pixels off the character's top drawing bounds
          const hitPDrawY = pDrawY + headMargin;
          const hitPDrawH = pDrawH - headMargin;

          // 1. Broad Phase AABB collision on the visual footprint
          if (pDrawX < eDrawX + eDrawW && pDrawX + pDrawW > eDrawX && 
              hitPDrawY < hitEDrawY + hitEDrawH && hitPDrawY + hitPDrawH > hitEDrawY) {
            
              // Fast-track simple procedural geometries
              if (ent.npcType.id === 'Bullet' && !ent.hit) {
                  ent.hit = true;
                  player.knockbackTimer = 0.5; // Short half-second airtime
                  player.isJumping = true;
                  player.vz = 400; // Propel physically backwards and upwards!
                  player.sitTimer = 0; // Do not apply hard sit stun
                  player.isFrozen = false;
                  hazardsHit++;
              }
              // 2. Narrow Phase Pixel-Perfect Collision via composite intersecting rect
              else if (ent.npcType.id !== 'Dragon' && offCtx && pSpriteSheet.complete && ent.sprite && ent.sprite.complete && player.knockbackTimer <= 0) {
                  const ix = Math.floor(Math.max(pDrawX, eDrawX));
                  const iy = Math.floor(Math.max(hitPDrawY, hitEDrawY));
                  const rightX = Math.ceil(Math.min(pDrawX + pDrawW, eDrawX + eDrawW));
                  const bottomY = Math.ceil(Math.min(hitPDrawY + hitPDrawH, hitEDrawY + hitEDrawH));
                  
                  const iw = rightX - ix;
                  const ih = bottomY - iy;

                  if (iw >= 1 && ih >= 1) {
                      collisionCanvas.width = iw;
                      collisionCanvas.height = ih;
                      offCtx.clearRect(0, 0, iw, ih);

                      // Draw Player directly onto intersection matrix securely
                      offCtx.save();
                      offCtx.translate(-ix, -iy);
                      offCtx.translate(pDrawX + pDrawW / 2, pDrawY + pDrawH / 2);
                      if (player.facingLeft) offCtx.scale(-1, 1);
                      offCtx.drawImage(pSpriteSheet, pSourceX, pSourceY, 256, 256, -pDrawW / 2, -pDrawH / 2, pDrawW, pDrawH);
                      offCtx.restore();

                      // Set context to overlap mask
                      offCtx.globalCompositeOperation = 'source-in';

                      // Draw NPC across overlap mask
                      offCtx.save();
                      offCtx.translate(-ix, -iy);
                      offCtx.translate(eDrawX + eDrawW / 2, eDrawY + eDrawH / 2);
                      if (ent.facingLeft !== !!ent.npcType.flipDefault) offCtx.scale(-1, 1);
                      const drawFrame = ent.npcType.id === 'Wringing Thorns' ? (ent.currentFrame <= 19 ? ent.currentFrame : 38 - ent.currentFrame) : ent.currentFrame;
                      const eCol = drawFrame % 5;
                      const eRow = Math.floor(drawFrame / 5);
                      offCtx.drawImage(ent.sprite, eCol * 256, eRow * 256, 256, 256, -eDrawW / 2, -eDrawH / 2, eDrawW, eDrawH);
                      offCtx.restore();

                      // Cleanup context
                      offCtx.globalCompositeOperation = 'source-over';

                      // Read pixel map
                      const imgData = offCtx.getImageData(0, 0, iw, ih).data;
                      let pixelHit = false;
                      for (let p = 3; p < imgData.length; p += 4) { // Only read Alpha channels
                          if (imgData[p] > 20) { // Slight alpha threshold protects against ghosted anti-aliasing edges 
                              pixelHit = true;
                              break;
                          }
                      }

                      if (pixelHit) {
                          ent.hit = true;
                          
                          if (ent.npcType.id === 'Strider') {
                              player.isMounted = true;
                              player.fastTimer = 30.0;
                              const sfx = new Audio('/sounds/MechaStriderAggro.ogg');
                              sfx.volume = 0.8;
                              sfx.play().catch(() => {});
                              continue;
                          }
                          
                          // Custom AI Traps
                          if (ent.isBaby && ent.parentId !== undefined) {
                              // Enrage the Mother!
                              const mother = entities.find(e => e.id === ent.parentId);
                              if (mother) {
                                  if (mother.enragedTimer <= 0) {
                                      const sfx = new Audio('/sounds/mSilithidWaspAggroA.ogg');
                                      sfx.volume = 0.8;
                                      sfx.play().catch(() => {});
                                  }
                                  mother.enragedTimer = 10.0;
                              }
                              // Baby silithids do not punish the player
                              continue;
                          }

                          const hitSfx = new Audio('/sounds/2hMaceMetalHitFlesh1A.ogg');
                          hitSfx.volume = 0.8;
                          hitSfx.play().catch(() => {});

                          player.isMounted = false;
                          player.fastTimer = 0;
                          player.slowTimer = 0;

                          if (ent.npcType.id === 'Wringing Thorns') {
                              player.x = ent.x + ent.width / 2 - player.width / 2;
                              player.y = ent.y + ent.height / 2 - player.height / 2;
                              
                              const sfxRoots = new Audio('/sounds/EntanglingRoots.ogg');
                              sfxRoots.volume = 0.8;
                              sfxRoots.play().catch(() => {});
                              
                              const sfxTroll = new Audio('/sounds/TrollMaleMainAttackC.ogg');
                              sfxTroll.volume = 0.8;
                              sfxTroll.play().catch(() => {});
                              
                              player.isTrappedTimer = 4.0;
                              player.trappedEntityId = ent.id;
                              player.sitTimer = 0;
                              player.isFrozen = false;
                          } else if (ent.npcType.id === 'Sea giant') {
                              player.knockbackTimer = 1.0;
                              player.isJumping = true;
                              player.vz = 800; // Super jump!
                              player.sitTimer = 0; // Ensure no sit override 
                              player.isFrozen = false;
                          } else if (ent.npcType.id === 'Basilisk') {
                              if (!player.isFrozen) {
                                  // Cache visual state exactly as it was!
                                  player.frozenSpriteId = (pSpriteSheet === sitImg ? 'sit' : pSpriteSheet === jumpImg ? 'jump' : pSpriteSheet === idleImg ? 'idle' : 'run');
                                  player.frozenFrame = pDrawnFrame;
                              }
                              player.sitTimer = 5.0;
                              player.isFrozen = true;
                          } else {
                              player.sitTimer = 2.0; 
                              player.isFrozen = false;
                              player.currentFrame = 0; // Reset counter for custom hit ticks
                          }
                          hazardsHit++; 
                      }
                  }
              }
          }
        }

         // Hyena Aggro Override
         let isAggro = false;
         if (ent.npcType.id === 'Hyena' && !ent.hit) {
             const dx = (player.x + player.width/2) - (ent.x + ent.width/2);
             const dy = (player.y + player.height/2) - (ent.y + ent.height/2);
             const distance = Math.sqrt(dx * dx + dy * dy);
             
             if (distance < 250) {
                 if (!ent.hasPlayedAggroSound) {
                     ent.hasPlayedAggroSound = true;
                     const sfx = new Audio('/sounds/HyenaAggroA.ogg');
                     sfx.volume = 0.8;
                     sfx.play().catch(() => {});
                 }
                 isAggro = true;
                 ent.state = 'walk';
                 ent.stateTimer = 1.0; 
                 if (ent.npcType.walk) ent.sprite = ent.npcType.walk;
                 
                 const aggroSpeed = 150; // Pixels per second (matches standard pacing speed)
                 ent.y += (dy / distance) * aggroSpeed * deltaTime;
                 
                 // Constrain Y geometry just like spawn so it doesn't float
                 const scaleMod = ent.npcType.scaleModifier || 1;
                 const minSafeY = skyHeight + ((96 * scaleMod) * 0.35);
                 if (ent.y < minSafeY) ent.y = minSafeY;
                 if (ent.y + ent.height > canvas.height) ent.y = canvas.height - ent.height;
                 
                 // Push localSpeedX to combat the implicit floor-scrolling deduction
                 ent.localSpeedX = ((dx / distance) * aggroSpeed) + activeRunSpeed;
                 ent.facingLeft = dx < 0; 
             }
         }

         // Mother Silithid Enraged Override
         if (ent.enragedTimer > 0) {
             ent.enragedTimer -= deltaTime;
             if (player.sitTimer > 0 || player.knockbackTimer > 0) {
                 ent.enragedTimer = 0; // Cancel enrage once player is punished
             } else {
                 isAggro = true;
                 ent.state = 'walk';
                 ent.stateTimer = 1.0;
                 if (ent.npcType.walk) ent.sprite = ent.npcType.walk;
                 
                 const dx = (player.x + player.width/2) - (ent.x + ent.width/2);
                 const dy = (player.y + player.height/2) - (ent.y + ent.height/2);
                 const distance = Math.max(1, Math.sqrt(dx * dx + dy * dy));
                 
                 const aggroSpeed = 400; // Terrifyingly fast Mother
                 ent.y += (dy / distance) * aggroSpeed * deltaTime;
                 
                 const scaleMod = ent.npcType.scaleModifier || 1;
                 const minSafeY = skyHeight + ((96 * scaleMod) * 0.35);
                 if (ent.y < minSafeY) ent.y = minSafeY;
                 if (ent.y + ent.height > canvas.height) ent.y = canvas.height - ent.height;
                 
                 ent.localSpeedX = ((dx / distance) * aggroSpeed) + activeRunSpeed;
                 ent.facingLeft = dx < 0; 
             }
         }

         // Process AI State
         ent.stateTimer -= deltaTime;
         if (!isAggro && ent.stateTimer <= 0) {
             if (ent.npcType.walk && ent.npcType.idle) {
                 ent.state = ent.state === 'walk' ? 'idle' : 'walk';
             } else if (ent.npcType.walk) {
                 ent.state = 'walk';
             } else {
                 ent.state = 'idle';
             }
             ent.stateTimer = 1.0 + Math.random() * 3.0; // 1 to 4 seconds before state switch
             
             // Walking speed logic (-X faces left, moves closer to player. +X runs away right)
             // Default is 0 when idle
             let localSpeedX = 0;
             let localSpeedY = 0;
             if (ent.state === 'walk') {
                 if (ent.npcType.id === 'Roc') {
                     localSpeedY = Math.random() > 0.5 ? 90 : -90; 
                 } else if (ent.npcType.id === 'Stinger') {
                     if (Math.random() < 0.25) { 
                         // 25% chance to furiously ZOOM diagonally
                         localSpeedX = Math.random() > 0.5 ? 350 : -350;
                         localSpeedY = Math.random() > 0.5 ? 250 : -250;
                     } else {
                         localSpeedX = Math.random() * 160 - 100; // Calm wandering
                         localSpeedY = Math.random() * 80 - 40;
                     }
                 } else {
                     localSpeedX = Math.random() * 220 - 140; // Bias towards moving left, speed doubled
                 }
             }
             ent.localSpeedX = localSpeedX;
             ent.localSpeedY = localSpeedY;

             // Determine facing based on local movement
             if (localSpeedX !== 0) {
                 ent.facingLeft = localSpeedX < 0;
             } else {
                 // Even if idle, generally look left towards the player
                 ent.facingLeft = true;
             }

             // Snap the active sprite layer
             ent.sprite = (ent.state === 'walk' ? ent.npcType.walk : ent.npcType.idle)!;
         }

         // Animate Entity Sprite
         ent.frameTimer += deltaTime;
         const baseFPS = 1 / 24;
         const finalFPS = ent.npcType.fpsModifier ? baseFPS / ent.npcType.fpsModifier : baseFPS;
         
         if (ent.frameTimer >= finalFPS) {
             ent.currentFrame++;
             
             if (ent.npcType.id === 'Pirate') {
                 ent.currentFrame = ent.currentFrame % 10; // Truncate explicitly to first 10 sprite frames
                 // Check if animation just rolled onto Frame 1
                 if (ent.currentFrame === 1 && ent.x + ent.width < canvas.width) {
                     // Execute procedural gunfire SFX payload bypassing cache locks
                     const sfx = new Audio(`/sounds/GunFire0${Math.floor(Math.random() * 3) + 1}.ogg`);
                     sfx.volume = 0.3;
                     sfx.play().catch(() => {});
                     
                     entities.push({
                        id: globalIdCounter++,
                        parentId: ent.id,
                        isBaby: true, 
                        enragedTimer: 0,
                        childSpawnTimer: 0,
                        x: ent.x - 42, 
                        y: ent.y - 73, 
                        width: 4, // Final smallest physical collision box
                        height: 4,
                        hit: false,
                        type: 'sit_hazard',
                        npcType: { id: 'Bullet' }, 
                        state: 'walk',
                        stateTimer: 99.0,
                        localSpeedX: -600, 
                        localSpeedY: 0,
                        facingLeft: true,
                        sprite: null as any, 
                        currentFrame: 0,
                        frameTimer: 0
                     });
                 }
             }
             else if (ent.npcType.id !== 'Wringing Thorns') {
                 ent.currentFrame = ent.currentFrame % 25;
             } else {
                 ent.currentFrame = ent.currentFrame % 38; // Ping-pong bounds strictly 0-19 and back
             }
             
             ent.frameTimer -= finalFPS;
         }

      } // End Entity Logic Loop

      // DEPTH SORTED RENDERING (Y-Sorting based on bottom edge of hitbox)
      // We collect all entities + the player, sort them by y, and draw them from top to bottom
      const renderables: any[] = [
         { type: 'player', ref: player, depth: player.y + player.height },
         ...entities.filter(e => !e.hit || (e.npcType.id === 'Wringing Thorns' && player.isTrappedTimer > 0 && e.id === player.trappedEntityId)).map(e => ({ type: 'npc', ref: e, depth: e.y + e.height }))
      ];
      renderables.sort((a, b) => a.depth - b.depth);

      for (const item of renderables) {
         if (item.type === 'npc') {
             const ent = item.ref;
             if (ent.sprite && ent.sprite.complete) {
                 ctx.save();
                 
                 // Assassin Stealth Mechanic
                 if (ent.npcType.id === 'Assassin') {
                     const dx = (player.x + player.width/2) - (ent.x + ent.width/2);
                     const dy = (player.y + player.height/2) - (ent.y + ent.height/2);
                     const distance = Math.sqrt(dx * dx + dy * dy);
                     
                     // Visible radius bounds
                     const fadeStartDist = 400; // Starts becoming visible
                     const fullyVisibleDist = 150; // 100% visible
                     
                     if (distance > fadeStartDist) {
                         ctx.globalAlpha = 0.0;
                     } else {
                         if (distance > fullyVisibleDist) {
                             ctx.globalAlpha = 1.0 - ((distance - fullyVisibleDist) / (fadeStartDist - fullyVisibleDist));
                         }

                         // Only play specific transition asset precisely once as transparency breaks
                         if (!ent.hasPlayedStealthSound) {
                             ent.hasPlayedStealthSound = true;
                             const sfx = new Audio('/sounds/Stealth.ogg');
                             sfx.volume = 0.7;
                             sfx.play().catch(() => {});
                         }
                     }
                 }
                 
                 const drawFrame = ent.npcType.id === 'Wringing Thorns' ? (ent.currentFrame <= 19 ? ent.currentFrame : 38 - ent.currentFrame) : ent.currentFrame;
                 const col = drawFrame % 5;
                 const row = Math.floor(drawFrame / 5);
                 const frameWidth = 1280 / 5;
                 const frameHeight = 1280 / 5;

                 // Scale logic
                 const scaleMod = ent.npcType.scaleModifier || 1;
                 const drawWidth = 96 * scaleMod; 
                 const drawHeight = 96 * scaleMod;
                 const drawX = ent.x - (drawWidth / 2) + (ent.width / 2);
                 const drawY = ent.y - drawHeight + ent.height + 4; 

                 ctx.translate(drawX + drawWidth / 2, drawY + drawHeight / 2);
                 const shouldFlip = ent.facingLeft !== !!ent.npcType.flipDefault;
                 if (shouldFlip) {
                     ctx.scale(-1, 1);
                 }
                 ctx.drawImage(ent.sprite, col * frameWidth, row * frameHeight, frameWidth, frameHeight, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
                 
                 // Procedural Help Marker (Bouncing Green Arrow)
                 if (ent.npcType.id === 'Strider') {
                     const bobbingOffset = Math.sin(time / 150) * 8; // Organic vertical wave translation
                     const arrowY = (-drawHeight / 2) - 30 + bobbingOffset; // Mapped inherently cleanly above the frame bounds
                     
                     ctx.fillStyle = '#22c55e'; // Bright active green highlight
                     ctx.beginPath();
                     ctx.moveTo(0, arrowY + 12);     // Bottom Point
                     ctx.lineTo(-12, arrowY - 2);    // Left Edge
                     ctx.lineTo(-5, arrowY - 2);     // Left Inner Shaft Core
                     ctx.lineTo(-5, arrowY - 16);    // Top Left Root
                     ctx.lineTo(5, arrowY - 16);     // Top Right Root
                     ctx.lineTo(5, arrowY - 2);      // Right Inner Shaft Core
                     ctx.lineTo(12, arrowY - 2);     // Right Edge
                     ctx.closePath();
                     ctx.fill();
                     
                     ctx.lineWidth = 2;
                     ctx.strokeStyle = '#022c22'; // High contrast primitive framing
                     ctx.stroke();
                 }

                 ctx.restore();
             } else {
                 if (ent.npcType && ent.npcType.id === 'Bullet') {
                     const visualRadius = (ent.width * 3) / 2;
                     
                     ctx.fillStyle = '#64748b'; // Outer metallic highlight rim
                     ctx.beginPath();
                     ctx.arc(ent.x + ent.width/2, ent.y + ent.height/2, visualRadius, 0, Math.PI * 2);
                     ctx.fill();
                     
                     ctx.fillStyle = '#0f172a'; // Heavy matte black iron core
                     ctx.beginPath();
                     ctx.arc(ent.x + ent.width/2, ent.y + ent.height/2, Math.max(1, visualRadius - 2), 0, Math.PI * 2);
                     ctx.fill();
                 } else {
                     ctx.fillStyle = '#334155';
                     ctx.fillRect(ent.x, ent.y, ent.width, ent.height);
                 }
             }
         } else if (item.type === 'player') {
             // 2. Draw Player (Sprite Sequence)
             if (player.slowTimer <= 0 || Math.floor(time / 100) % 2 === 0) {
                ctx.save();
                
                if (player.isMounted) {
                    const striderRef = npcTypes.find(n => n.id === 'Strider');
                    if (striderRef && striderRef.walk) {
                        const sDrawW = 96 * 1.5;
                        const sDrawH = 96 * 1.5;
                        const sDrawX = player.x - (sDrawW / 2) + (player.width / 2);
                        const sDrawY = player.y - player.z - sDrawH + player.height + 4;
                        
                        ctx.save();
                        const sSourceX = (player.currentFrame % 5) * 256;
                        const sSourceY = Math.floor(player.currentFrame / 5) * 256;
                        
                        ctx.translate(sDrawX + sDrawW / 2, sDrawY + sDrawH / 2);
                        if (player.facingLeft) ctx.scale(-1, 1);
                        ctx.drawImage(striderRef.walk, sSourceX, sSourceY, 256, 256, -sDrawW / 2, -sDrawH / 2, sDrawW, sDrawH);
                        ctx.restore();
                    }
                } else if (player.fastTimer > 0) {
                    ctx.beginPath();
                    ctx.arc(player.x + player.width/2, player.y - player.z + player.height/2, player.width * 1.5, 0, Math.PI * 2);
                    ctx.fillStyle = 'rgba(250, 204, 21, 0.4)';
                    ctx.fill();
                } else if (player.slowTimer > 0) {
                    ctx.beginPath();
                    ctx.arc(player.x + player.width/2, player.y - player.z + player.height/2, player.width * 1.5, 0, Math.PI * 2);
                    ctx.fillStyle = 'rgba(185, 28, 28, 0.4)';
                    ctx.fill();
                }

                try {
                   if (pSpriteSheet.complete) {
                      if (player.isFrozen) {
                          ctx.filter = 'grayscale(100%)';
                      }
                      // Mount bob formula mapping 0 to 2 px smoothly based on time
                      const mountBob = Math.sin(time / 40) * 2;
                      const activePDrawY = player.isMounted ? pDrawY - 62 + mountBob : pDrawY;
                      const mountOffsetX = player.facingLeft ? -10 : 10; // Dynamic asymmetric mirroring
                      const activePDrawX = player.isMounted ? pDrawX + mountOffsetX : pDrawX;

                      if (player.facingLeft) {
                         ctx.translate(activePDrawX + pDrawW / 2, activePDrawY + pDrawH / 2);
                         ctx.scale(-1, 1);
                         ctx.drawImage(pSpriteSheet, pSourceX, pSourceY, 256, 256, -pDrawW / 2, -pDrawH / 2, pDrawW, pDrawH);
                      } else {
                         ctx.drawImage(pSpriteSheet, pSourceX, pSourceY, 256, 256, activePDrawX, activePDrawY, pDrawW, pDrawH);
                      }
                   }
                } catch(e) {}
                
                ctx.restore();
             }
         }
      }
      
      // Update and Draw Distance Score (Top Right)
      distanceTraveled += activeRunSpeed * deltaTime;
      const score = Math.floor(distanceTraveled / 10); // 1 point per 10 pixels scrolled
      
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`SCORE: ${score.toString().padStart(5, '0')}`, canvas.width - 20, 40);

      // Update and Draw Time (Top Center)
      if (isPlaying) {
          timeRemaining -= deltaTime;
      }
      if (timeRemaining < 0) timeRemaining = 0;

      if (timeRemaining <= 210.0 && !hasSpawnedDragon) {
          hasSpawnedDragon = true;
          entities.push({
              id: globalIdCounter++,
              enragedTimer: 0,
              childSpawnTimer: 0,
              x: canvas.width + 200, // Starts off-screen right
              y: canvas.height / 2 + 480, // Compensates for the 960px bottom-up scale offset, plotting its core visually down the centerline
              width: 24, // Irrelevant logical boundary
              height: 24, // Irrelevant logical boundary
              hit: false, // Ensures rendering pipeline explicitly paints the sequence
              type: 'sit_hazard',
              npcType: npcTypes.find(n => n.id === 'Dragon')!,
              state: 'walk',
              stateTimer: 999.0, // Permanent pacing
              localSpeedX: -800, // Supersonic flight velocity
              localSpeedY: 0, // Perfectly level trajectory
              facingLeft: true,
              sprite: npcTypes.find(n => n.id === 'Dragon')!.walk!,
              currentFrame: 0,
              frameTimer: 0
          });
      }

      const mins = Math.floor(timeRemaining / 60);
      const secs = Math.floor(timeRemaining % 60);
      const ms = Math.floor((timeRemaining % 1) * 100);
      
      ctx.textAlign = 'center';
      ctx.fillStyle = timeRemaining < 10 ? '#ef4444' : '#ffffff'; // Turn red in last 10 seconds
      ctx.fillText(`${mins}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`, canvas.width / 2, 40);

      // Handle Game Over State
      if (timeRemaining <= 0) {
         ctx.fillStyle = 'rgba(0,0,0,0.85)';
         ctx.fillRect(0, 0, canvas.width, canvas.height);
         
         ctx.fillStyle = '#ea580c';
         ctx.font = 'black 48px monospace';
         ctx.fillText('ENDURANCE COMPLETE', canvas.width / 2, canvas.height / 2 - 40);
         
         ctx.fillStyle = '#ffffff';
         ctx.font = 'bold 32px monospace';
         ctx.fillText(`FINAL SCORE: ${score.toString().padStart(5, '0')}`, canvas.width / 2, canvas.height / 2 + 20);

         ctx.fillStyle = '#a1a1aa';
         ctx.font = '20px monospace';
         ctx.fillText(`Hazards hit: ${hazardsHit}  |  Boosts collected: ${boostsCollected}`, canvas.width / 2, canvas.height / 2 + 60);

         setIsGameOver(true);
         return; // Halts the requestAnimationFrame loop entirely
      }

      animationFrameId = requestAnimationFrame(render);
    };

    // Start loop
    animationFrameId = requestAnimationFrame(render);

    // Cleanup
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, gameId]);

  return (
    <div className="flex flex-col items-center justify-center space-y-4 w-full flex-1 pb-6 min-h-0">
       <div className="bg-black border-4 border-zinc-800 rounded-lg p-2 shadow-2xl relative ring-1 ring-zinc-700/50 w-full h-full flex overflow-hidden">
         {!isPlaying && (
           <div className="absolute inset-0 z-20 flex flex-col items-center justify-center rounded bg-zinc-950/20">
              <img 
                src="/sprites/Hardware Store Game Logo.png" 
                alt="Hardware Store Game" 
                className="w-[600px] max-w-[80%] object-contain mb-12 drop-shadow-[0_20px_20px_rgba(0,0,0,0.8)] hover:scale-105 transition-transform duration-[2000ms] ease-in-out"
              />
              <button 
                onClick={() => setIsPlaying(true)}
                className="bg-brand text-white font-black text-2xl px-12 py-4 rounded-lg shadow-[0_0_40px_rgba(234,88,12,0.8)] hover:bg-brand-hover hover:scale-105 active:scale-95 transition-all outline-none"
              >
                PLAY (3:43)
              </button>
           </div>
         )}
         {isPlaying && isPaused && !isGameOver && (
           <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm rounded">
              <span className="text-4xl font-black mb-6 tracking-widest">PAUSED</span>
              <div className="flex gap-4">
                 <button 
                   onClick={togglePause}
                   className="bg-zinc-800 text-white font-bold text-xl px-10 py-3 rounded-lg border border-zinc-700 hover:bg-zinc-700 active:scale-95 transition-all outline-none"
                 >
                   RESUME
                 </button>
                 <button 
                   onClick={restartGame}
                   className="bg-red-950/40 text-red-500 font-bold text-xl px-10 py-3 rounded-lg border border-red-900/50 hover:bg-red-900/50 active:scale-95 transition-all outline-none"
                 >
                   RESTART
                 </button>
              </div>
           </div>
         )}
         {isGameOver && (
           <div className="absolute bottom-16 right-1/2 translate-x-1/2 z-20">
               <button 
                 onClick={restartGame}
                 className="bg-brand text-white font-black text-xl px-12 py-4 rounded-lg shadow-[0_0_20px_rgba(234,88,12,0.5)] hover:bg-brand-hover hover:scale-105 active:scale-95 transition-all outline-none"
               >
                 PLAY AGAIN
               </button>
           </div>
         )}
         {isPlaying && !isPaused && !isGameOver && (
           <>
             <button 
               onClick={togglePause}
               className="absolute top-4 left-4 z-10 bg-surface border border-border px-4 py-1.5 rounded-md text-xs font-bold tracking-widest hover:bg-surface-hover text-zinc-300 transition-colors"
             >
               PAUSE
             </button>
             <button 
               onClick={() => skipRef.current?.()}
               className="absolute bottom-4 right-4 z-10 bg-red-950/40 border border-red-900/50 px-3 py-1.5 rounded text-[10px] font-mono text-red-500 hover:bg-red-900/50 transition-colors"
             >
               [DEV] SKIP 3M 30S
             </button>
           </>
         )}
         <canvas 
            ref={canvasRef} 
            className="w-full h-full bg-background block rounded [image-rendering:pixelated]"
          />
       </div>
       <div className="flex flex-wrap justify-center gap-4 text-xs font-mono text-zinc-500">
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">W</kbd> / <kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">↑</kbd> Up</div>
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">S</kbd> / <kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">↓</kbd> Down</div>
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">A</kbd> / <kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">←</kbd> Left</div>
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">D</kbd> / <kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">→</kbd> Right</div>
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">Space</kbd> Jump</div>
       </div>
    </div>
  );
}
