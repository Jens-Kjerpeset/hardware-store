'use client';
import { useEffect, useRef, useState } from 'react';

export default function HardwareStoreGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const skipRef = useRef<(() => void) | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [gameId, setGameId] = useState(0);
  const isPausedRef = useRef(false);

  const togglePause = () => {
    isPausedRef.current = !isPausedRef.current;
    setIsPaused(isPausedRef.current);
  };

  const restartGame = () => {
    setIsPaused(false);
    isPausedRef.current = false;
    setIsGameOver(false);
    setGameId(prev => prev + 1);
    setIsPlaying(true);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleResize = () => {
      // Sync internal resolution with display size
      canvas.width = canvas.parentElement?.clientWidth || 800;
      canvas.height = canvas.parentElement?.clientHeight || 400;
      ctx.imageSmoothingEnabled = false;
    };
    
    // Initial size mapping and resize listener
    handleResize();
    window.addEventListener('resize', handleResize);

    if (!isPlaying) {
      // Just draw a static dark background if waiting for play
      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      return () => {
        window.removeEventListener('resize', handleResize);
      };
    }

    // Load Sprites
    const idleImg = new Image();
    idleImg.src = '/sprites/Reapz-idle.png';
    const runImg = new Image();
    runImg.src = '/sprites/Reapz-run.png';
    const jumpImg = new Image();
    jumpImg.src = '/sprites/Reapz-jump.png';
    const sitImg = new Image();
    sitImg.src = '/sprites/Reapz-sit.png';
    const floorImg = new Image();
    floorImg.src = '/sprites/desert_floor.jpeg';

    // NPC Definitions Map
    const loadImg = (src: string) => { const img = new Image(); img.src = src; return img; };
    type NPCType = { id: string, walk?: HTMLImageElement, idle?: HTMLImageElement, scaleModifier?: number, fpsModifier?: number, flipDefault?: boolean };
    const npcTypes: NPCType[] = [
      { id: 'Bog Lord', idle: loadImg('/sprites/Bog Lord-idle.png'), scaleModifier: 1.5 },
      { id: 'Assassin', walk: loadImg('/sprites/Assassin-walk.png') },
      { id: 'Roc', walk: loadImg('/sprites/Roc-walk.png') },
      { id: 'Stinger', walk: loadImg('/sprites/Stinger-walk.png'), flipDefault: true, scaleModifier: 1.5 },
      // Basilisk inherently walks backwards so we flip it by default and scale it 2x
      { id: 'Basilisk', walk: loadImg('/sprites/Basilisk-walk.png'), idle: loadImg('/sprites/Basilisk-idle.png'), scaleModifier: 2, flipDefault: true },
      { id: 'Hyena', walk: loadImg('/sprites/Hyena-walk.png'), idle: loadImg('/sprites/Hyena-idle.png') },
      // Sea Giant is towering (4x) and moves slowly (half fps)
      { id: 'Sea giant', walk: loadImg('/sprites/Sea giant-walk.png'), idle: loadImg('/sprites/Sea giant-idle.png'), scaleModifier: 4, fpsModifier: 0.5 },
      { id: 'Silithid', walk: loadImg('/sprites/Silithid-walk.png'), idle: loadImg('/sprites/Silithid-idle.png'), scaleModifier: 1.5, fpsModifier: 4.0 }
    ];

    // Game state
    let animationFrameId: number;
    let lastTime = performance.now();
    
    const player = {
      x: 100,
      y: canvas.height / 2 - 12,
      z: 0,
      vz: 0,
      isJumping: false,
      slowTimer: 0,
      fastTimer: 0,
      sitTimer: 0,
      width: 24,
      height: 24,
      speed: 300, // pixels per second vertically
      frameTimer: 0,
      currentFrame: 0,
      facingLeft: false,
    };

    const keys = {
      ArrowUp: false,
      ArrowDown: false,
      ArrowLeft: false,
      ArrowRight: false,
      w: false,
      s: false,
      a: false,
      d: false,
    };

    let backgroundOffset = 0;
    const baseRunSpeed = 200; // pixels per second background scroll
    let distanceTraveled = 0;
    let timeRemaining = 223.0; // 3 minutes 43 seconds
    
    let hazardsHit = 0;
    let boostsCollected = 0;

    if (isPlaying) {
      // Map the debug skip function to the ref
      skipRef.current = () => {
        timeRemaining = Math.max(0.5, timeRemaining - 210.0);
      };
    }

    type Entity = { 
        x: number, y: number, width: number, height: number, 
        hit: boolean, type: 'sit_hazard',
        npcType: NPCType, state: 'walk' | 'idle', stateTimer: number, localSpeedX: number, facingLeft: boolean,
        sprite: HTMLImageElement, currentFrame: number, frameTimer: number 
    };
    let entities: Entity[] = [];
    let spawnTimer = 1.0; // First obstacle in 1 second

    // Input listening
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
         if (!player.isJumping) {
            player.vz = 400; // Jump power
            player.isJumping = true;
         }
         e.preventDefault();
         return;
      }
      if (keys.hasOwnProperty(e.key)) {
        keys[e.key as keyof typeof keys] = true;
        // Prevent default scrolling for arrow keys while focused on the game
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
          e.preventDefault();
        }
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (keys.hasOwnProperty(e.key)) {
        keys[e.key as keyof typeof keys] = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Main loop
    const render = (time: number) => {
      const deltaTime = (time - lastTime) / 1000;
      lastTime = time;

      if (isPausedRef.current) {
         animationFrameId = requestAnimationFrame(render);
         return;
      }

      // Animate Sprite Frame based on state constraints
      player.frameTimer += deltaTime;

      // Slower animation when running backwards
      let fpsThreshold = 1 / 24; // Default 24 FPS
      if (player.facingLeft && !player.isJumping && player.sitTimer <= 0) {
         fpsThreshold = 1 / 16; // 16 FPS
      }

      if (player.frameTimer >= fpsThreshold) {
         let minFrame = 0;
         let maxFrame = 24; // 25 frames total
         
         // User requested Jump animation to snap to specific indices
         if (player.sitTimer > 0) {
            // Sit uses a custom mapped time sequence, so let currentFrame count up infinitely
            minFrame = 0;
            maxFrame = 999999;
         } else if (player.isJumping) {
            minFrame = 2; // Frame 3 (0-indexed)
            maxFrame = 14; // Frame 15 (0-indexed)
         } else {
            // Default running animation constraints
            minFrame = 0; // Frame 1 (0-indexed)
            maxFrame = 22; // Frame 23 (0-indexed)
         }

         player.currentFrame++;
         if (player.currentFrame < minFrame || player.currentFrame > maxFrame) {
             player.currentFrame = minFrame;
         }

         player.frameTimer -= fpsThreshold;
      }

      // Handle active tracking debuffs and buffs
      if (player.sitTimer > 0) {
        player.sitTimer -= deltaTime;
        if (player.sitTimer < 0) player.sitTimer = 0;
      }
      if (player.slowTimer > 0) {
        player.slowTimer -= deltaTime;
        if (player.slowTimer < 0) player.slowTimer = 0;
      }
      if (player.fastTimer > 0) {
        player.fastTimer -= deltaTime;
        if (player.fastTimer < 0) player.fastTimer = 0;
      }

      let activePlayerSpeed = player.speed;
      let activeRunSpeed = baseRunSpeed;

      if (player.sitTimer > 0) {
        activePlayerSpeed = 0;
        activeRunSpeed = 0;
      } else if (player.slowTimer > 0) {
        activePlayerSpeed *= 0.5;
        activeRunSpeed *= 0.5;
      } else if (player.fastTimer > 0) {
        activePlayerSpeed *= 1.6;
        activeRunSpeed *= 1.6;
      }

      // Update Player Y
      if (keys.ArrowUp || keys.w) {
        player.y -= activePlayerSpeed * deltaTime;
      }
      if (keys.ArrowDown || keys.s) {
        player.y += activePlayerSpeed * deltaTime;
      }
      
      // Update Player X (auto-runner defaults to facing right unless actively running left)
      player.facingLeft = (keys.ArrowLeft || keys.a) && !(keys.ArrowRight || keys.d);

      if (keys.ArrowLeft || keys.a) {
        player.x -= activePlayerSpeed * deltaTime;
      }
      if (keys.ArrowRight || keys.d) {
        player.x += activePlayerSpeed * deltaTime;
      }
      
      // Update Player Z (Jumping)
      if (player.isJumping) {
        player.z += player.vz * deltaTime;
        player.vz -= 1400 * deltaTime; // Gravity
        if (player.z <= 0) {
           player.z = 0;
           player.vz = 0;
           player.isJumping = false;
        }
      }

      // Clamp player bounds tightly to canvas
      const skyHeight = 5 * 32; // 160 pixels (top 5 squares)
      if (player.y < skyHeight) player.y = skyHeight;
      if (player.y + player.height > canvas.height) {
        player.y = canvas.height - player.height;
      }
      
      if (player.x < 0) player.x = 0;
      if (player.x + player.width > canvas.width) {
        player.x = canvas.width - player.width;
      }

      // Update background moving left (simulating player running right)
      backgroundOffset -= activeRunSpeed * deltaTime;

      // 1. Draw Sky Background
      ctx.fillStyle = '#0a0a0a'; 
      ctx.fillRect(0, 0, canvas.width, skyHeight);
      ctx.fillStyle = 'rgba(56, 189, 248, 0.1)'; // Sky tint
      ctx.fillRect(0, 0, canvas.width, skyHeight);

      // 2. Draw Repeating Desert Floor
      const groundHeight = canvas.height - skyHeight;
      if (floorImg.complete && floorImg.naturalWidth > 0) {
          // Scale logic to preserve the visual texture while locking height
          const ratio = groundHeight / floorImg.naturalHeight;
          const renderWidth = Math.max(1024, floorImg.naturalWidth * Math.max(0.2, ratio)); 
          
          let localOffset = backgroundOffset % renderWidth;
          if (localOffset > 0) localOffset -= renderWidth; // guarantee negative shift
          
          try {
             // Draw enough tiles to safely cover dynamically resizing ultra-wide monitors
             ctx.drawImage(floorImg, 0, 0, floorImg.naturalWidth, floorImg.naturalHeight, localOffset, skyHeight, renderWidth, groundHeight);
             ctx.drawImage(floorImg, 0, 0, floorImg.naturalWidth, floorImg.naturalHeight, localOffset + renderWidth, skyHeight, renderWidth, groundHeight);
             ctx.drawImage(floorImg, 0, 0, floorImg.naturalWidth, floorImg.naturalHeight, localOffset + renderWidth * 2, skyHeight, renderWidth, groundHeight);
          } catch(e) {}
      } else {
          // Fallback if image not ready
          ctx.fillStyle = '#292524'; // Warm stone tint
          ctx.fillRect(0, skyHeight, canvas.width, groundHeight);
      }

      // Spawn Entities
      spawnTimer -= deltaTime;
      if (spawnTimer <= 0) {
        let width = 24;
        let height = 24;
        
        const npcType = npcTypes[Math.floor(Math.random() * npcTypes.length)];
        let startState: 'walk' | 'idle' = npcType.walk ? 'walk' : 'idle';
        if (npcType.walk && npcType.idle && Math.random() > 0.5) startState = 'idle';

        // Expanded Hitboxes based on NPC type
        if (npcType.id === 'Bog Lord') {
            width = 48; // Increased from 24
            height = 48;
        } else if (npcType.id === 'Sea giant') {
            width = 80; // Greatly increased from 24
            height = 80;
        }

        // Local pacing speed (-X is walking left, +X is walking right). Scaled 2x.
        const localSpeedX = startState === 'walk' ? (Math.random() * 220 - 140) : 0;
        
        entities.push({
          x: canvas.width + 50,
          y: skyHeight + Math.random() * (canvas.height - skyHeight - height),
          width,
          height,
          hit: false,
          type: 'sit_hazard', // All NPCs force 2 second sit
          npcType,
          state: startState,
          stateTimer: 1.0 + Math.random() * 3.0,
          localSpeedX,
          facingLeft: localSpeedX < 0 || localSpeedX === 0, // default facing left if standing still
          sprite: (startState === 'walk' ? npcType.walk : npcType.idle)!,
          currentFrame: Math.floor(Math.random() * 25),
          frameTimer: 0
        });
        // Slower spawn timer so the screen isn't entirely flooded with instant sits
        spawnTimer = 1.0 + Math.random() * 2.5; 
      }

      // Draw and Update Entities
      for (let i = entities.length - 1; i >= 0; i--) {
        const ent = entities[i];
        
        // Background flows left, local pacing speed adds to the vector
        ent.x -= (activeRunSpeed + -ent.localSpeedX) * deltaTime;
        
        if (ent.x + ent.width < 0) {
          entities.splice(i, 1);
          continue;
        }

        // Collision Check
        if (!ent.hit && player.z < 24) {
          const overlapX = player.x < ent.x + ent.width && player.x + player.width > ent.x;
          const overlapY = player.y < ent.y + ent.height && player.y + player.height > ent.y;
          
          if (overlapX && overlapY) {
            ent.hit = true;
            
            // Any NPC hit triggers 2 second sit
            player.sitTimer = 2.0; 
            player.fastTimer = 0;
            player.slowTimer = 0;
            player.currentFrame = 0; // Reset counter for custom hit ticks
            hazardsHit++; 
          }
        }

         // Process AI State
         ent.stateTimer -= deltaTime;
         if (ent.stateTimer <= 0) {
             if (ent.npcType.walk && ent.npcType.idle) {
                 ent.state = ent.state === 'walk' ? 'idle' : 'walk';
             } else if (ent.npcType.walk) {
                 ent.state = 'walk';
             } else {
                 ent.state = 'idle';
             }
             ent.stateTimer = 1.0 + Math.random() * 3.0; // 1 to 4 seconds before state switch
             
             // Walking speed logic (-X faces left, moves closer to player. +X runs away right)
             // Default is 0 when idle
             let localSpeedX = 0;
             if (ent.state === 'walk') {
                 localSpeedX = Math.random() * 220 - 140; // Bias towards moving left, speed doubled
             }
             ent.localSpeedX = localSpeedX;
             
             // Determine facing based on local movement
             if (localSpeedX !== 0) {
                 ent.facingLeft = localSpeedX < 0;
             } else {
                 // Even if idle, generally look left towards the player
                 ent.facingLeft = true;
             }

             // Snap the active sprite layer
             ent.sprite = (ent.state === 'walk' ? ent.npcType.walk : ent.npcType.idle)!;
         }

         // Animate Entity Sprite
         ent.frameTimer += deltaTime;
         const baseFPS = 1 / 24;
         const finalFPS = ent.npcType.fpsModifier ? baseFPS / ent.npcType.fpsModifier : baseFPS;
         
         if (ent.frameTimer >= finalFPS) {
             ent.currentFrame = (ent.currentFrame + 1) % 25;
             ent.frameTimer -= finalFPS;
         }

      } // End Entity Logic Loop

      // DEPTH SORTED RENDERING (Y-Sorting based on bottom edge of hitbox)
      // We collect all entities + the player, sort them by y, and draw them from top to bottom
      const renderables: any[] = [
         { type: 'player', ref: player, depth: player.y + player.height },
         ...entities.filter(e => !e.hit).map(e => ({ type: 'npc', ref: e, depth: e.y + e.height }))
      ];
      renderables.sort((a, b) => a.depth - b.depth);

      for (const item of renderables) {
         if (item.type === 'npc') {
             const ent = item.ref;
             if (ent.sprite && ent.sprite.complete) {
                 ctx.save();
                 const col = ent.currentFrame % 5;
                 const row = Math.floor(ent.currentFrame / 5);
                 const frameWidth = 1280 / 5;
                 const frameHeight = 1280 / 5;

                 // Scale logic
                 const scaleMod = ent.npcType.scaleModifier || 1;
                 const drawWidth = 96 * scaleMod; 
                 const drawHeight = 96 * scaleMod;
                 const drawX = ent.x - (drawWidth / 2) + (ent.width / 2);
                 const drawY = ent.y - drawHeight + ent.height + 4; 

                 ctx.translate(drawX + drawWidth / 2, drawY + drawHeight / 2);
                 const shouldFlip = ent.facingLeft !== !!ent.npcType.flipDefault;
                 if (shouldFlip) {
                     ctx.scale(-1, 1);
                 }
                 ctx.drawImage(ent.sprite, col * frameWidth, row * frameHeight, frameWidth, frameHeight, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
                 ctx.restore();
             } else {
                 ctx.fillStyle = '#334155';
                 ctx.fillRect(ent.x, ent.y, ent.width, ent.height);
             }
         } else if (item.type === 'player') {
             // 2. Draw Player (Sprite Sequence)
             let activeSpriteSheet = runImg;
             if (player.sitTimer > 0) {
                activeSpriteSheet = sitImg;
             } else if (player.isJumping) {
                activeSpriteSheet = jumpImg;
             } else if (activeRunSpeed === 0) {
                activeSpriteSheet = idleImg; 
             }

             if (player.slowTimer <= 0 || Math.floor(time / 100) % 2 === 0) {
                ctx.save();
                
                if (player.fastTimer > 0) {
                    ctx.beginPath();
                    ctx.arc(player.x + player.width/2, player.y - player.z + player.height/2, player.width * 1.5, 0, Math.PI * 2);
                    ctx.fillStyle = 'rgba(250, 204, 21, 0.4)';
                    ctx.fill();
                } else if (player.slowTimer > 0) {
                    ctx.beginPath();
                    ctx.arc(player.x + player.width/2, player.y - player.z + player.height/2, player.width * 1.5, 0, Math.PI * 2);
                    ctx.fillStyle = 'rgba(185, 28, 28, 0.4)';
                    ctx.fill();
                }

                let drawnFrameIndex = player.currentFrame;

                if (player.sitTimer > 0) {
                    if (player.currentFrame === 0) drawnFrameIndex = 0;
                    else if (player.currentFrame === 1) drawnFrameIndex = 9;
                    else if (player.currentFrame === 2) drawnFrameIndex = 18;
                    else {
                        const tick = Math.floor((player.currentFrame - 3) / 2);
                        const pp = tick % 4;
                        if (pp <= 2) {
                            drawnFrameIndex = 22 + pp;
                        } else {
                            drawnFrameIndex = 22 + (4 - pp);
                        }
                    }
                }

                const col = drawnFrameIndex % 5;
                const row = Math.floor(drawnFrameIndex / 5);
                const frameWidth = 1280 / 5;
                const frameHeight = 1280 / 5;
                const sourceX = col * frameWidth;
                const sourceY = row * frameHeight;
                
                const drawWidth = 96; 
                const drawHeight = 96;
                const drawX = player.x - (drawWidth / 2) + (player.width / 2);
                const drawY = player.y - player.z - (drawHeight) + player.height + 4;

                try {
                   if (activeSpriteSheet.complete) {
                      if (player.facingLeft) {
                         ctx.translate(drawX + drawWidth / 2, drawY + drawHeight / 2);
                         ctx.scale(-1, 1);
                         ctx.drawImage(activeSpriteSheet, sourceX, sourceY, frameWidth, frameHeight, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
                      } else {
                         ctx.drawImage(activeSpriteSheet, sourceX, sourceY, frameWidth, frameHeight, drawX, drawY, drawWidth, drawHeight);
                      }
                   }
                } catch(e) {}
                
                ctx.restore();
             }
         }
      }
      
      // Update and Draw Distance Score (Top Right)
      distanceTraveled += activeRunSpeed * deltaTime;
      const score = Math.floor(distanceTraveled / 10); // 1 point per 10 pixels scrolled
      
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`SCORE: ${score.toString().padStart(5, '0')}`, canvas.width - 20, 40);

      // Update and Draw Time (Top Center)
      timeRemaining -= deltaTime;
      if (timeRemaining < 0) timeRemaining = 0;

      const mins = Math.floor(timeRemaining / 60);
      const secs = Math.floor(timeRemaining % 60);
      const ms = Math.floor((timeRemaining % 1) * 100);
      
      ctx.textAlign = 'center';
      ctx.fillStyle = timeRemaining < 10 ? '#ef4444' : '#ffffff'; // Turn red in last 10 seconds
      ctx.fillText(`${mins}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`, canvas.width / 2, 40);

      // Handle Game Over State
      if (timeRemaining <= 0) {
         ctx.fillStyle = 'rgba(0,0,0,0.85)';
         ctx.fillRect(0, 0, canvas.width, canvas.height);
         
         ctx.fillStyle = '#ea580c';
         ctx.font = 'black 48px monospace';
         ctx.fillText('ENDURANCE COMPLETE', canvas.width / 2, canvas.height / 2 - 40);
         
         ctx.fillStyle = '#ffffff';
         ctx.font = 'bold 32px monospace';
         ctx.fillText(`FINAL SCORE: ${score.toString().padStart(5, '0')}`, canvas.width / 2, canvas.height / 2 + 20);

         ctx.fillStyle = '#a1a1aa';
         ctx.font = '20px monospace';
         ctx.fillText(`Hazards hit: ${hazardsHit}  |  Boosts collected: ${boostsCollected}`, canvas.width / 2, canvas.height / 2 + 60);

         setIsGameOver(true);
         return; // Halts the requestAnimationFrame loop entirely
      }

      animationFrameId = requestAnimationFrame(render);
    };

    // Start loop
    animationFrameId = requestAnimationFrame(render);

    // Cleanup
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, gameId]);

  return (
    <div className="flex flex-col items-center justify-center space-y-4 w-full flex-1 pb-6 min-h-0">
       <div className="bg-black border-4 border-zinc-800 rounded-lg p-2 shadow-2xl relative ring-1 ring-zinc-700/50 w-full h-full flex overflow-hidden">
         {!isPlaying && (
           <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm rounded">
              <button 
                onClick={() => setIsPlaying(true)}
                className="bg-brand text-white font-black text-2xl px-12 py-4 rounded-lg shadow-[0_0_20px_rgba(234,88,12,0.5)] hover:bg-brand-hover hover:scale-105 active:scale-95 transition-all outline-none"
              >
                PLAY (3:43)
              </button>
           </div>
         )}
         {isPlaying && isPaused && !isGameOver && (
           <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm rounded">
              <span className="text-4xl font-black mb-6 tracking-widest">PAUSED</span>
              <div className="flex gap-4">
                 <button 
                   onClick={togglePause}
                   className="bg-zinc-800 text-white font-bold text-xl px-10 py-3 rounded-lg border border-zinc-700 hover:bg-zinc-700 active:scale-95 transition-all outline-none"
                 >
                   RESUME
                 </button>
                 <button 
                   onClick={restartGame}
                   className="bg-red-950/40 text-red-500 font-bold text-xl px-10 py-3 rounded-lg border border-red-900/50 hover:bg-red-900/50 active:scale-95 transition-all outline-none"
                 >
                   RESTART
                 </button>
              </div>
           </div>
         )}
         {isGameOver && (
           <div className="absolute bottom-16 right-1/2 translate-x-1/2 z-20">
               <button 
                 onClick={restartGame}
                 className="bg-brand text-white font-black text-xl px-12 py-4 rounded-lg shadow-[0_0_20px_rgba(234,88,12,0.5)] hover:bg-brand-hover hover:scale-105 active:scale-95 transition-all outline-none"
               >
                 PLAY AGAIN
               </button>
           </div>
         )}
         {isPlaying && !isPaused && !isGameOver && (
           <>
             <button 
               onClick={togglePause}
               className="absolute top-4 left-4 z-10 bg-surface border border-border px-4 py-1.5 rounded-md text-xs font-bold tracking-widest hover:bg-surface-hover text-zinc-300 transition-colors"
             >
               PAUSE
             </button>
             <button 
               onClick={() => skipRef.current?.()}
               className="absolute bottom-4 right-4 z-10 bg-red-950/40 border border-red-900/50 px-3 py-1.5 rounded text-[10px] font-mono text-red-500 hover:bg-red-900/50 transition-colors"
             >
               [DEV] SKIP 3M 30S
             </button>
           </>
         )}
         <canvas 
            ref={canvasRef} 
            className="w-full h-full bg-background block rounded [image-rendering:pixelated]"
          />
       </div>
       <div className="flex flex-wrap justify-center gap-4 text-xs font-mono text-zinc-500">
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">W</kbd> / <kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">↑</kbd> Up</div>
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">S</kbd> / <kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">↓</kbd> Down</div>
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">A</kbd> / <kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">←</kbd> Left</div>
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">D</kbd> / <kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">→</kbd> Right</div>
         <div className="flex items-center gap-1"><kbd className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">Space</kbd> Jump</div>
       </div>
    </div>
  );
}
